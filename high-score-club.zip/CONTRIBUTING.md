# Contributing

Please submit pull requests for documentation, frontend mockups, and contract improvements.