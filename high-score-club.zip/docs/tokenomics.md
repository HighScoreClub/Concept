# $SCORE Tokenomics

1,000,000,000 fixed supply, allocation, tiers, fees, sinks, etc.