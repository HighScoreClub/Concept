# Meme, Narrative & Community

Leaderboard culture, archetypes, share assets, rituals, community governance.