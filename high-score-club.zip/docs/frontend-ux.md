# Frontend UX

Mobile wrapper, portrait gameplay, X login, dashboard, leaderboard, challenge flows.