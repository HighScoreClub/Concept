# Launch & Distribution

Phase 0 alpha, Phase 1 beta, Phase 2 token liquidity, influencer strategy, retention metrics.