# High Score Club Whitepaper

" + (the full whitepaper text we generated)