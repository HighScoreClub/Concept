// Rust skeleton for HighScoreCore program on Solana
fn main() {}