# HighScoreCore Smart Contract

Solana SPL token + escrow logic for PvP challenges. IDL.json included.
