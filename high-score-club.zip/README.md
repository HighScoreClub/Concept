# High Score Club

High Score Club is a Web3, skill-based competitive gaming platform built on Solana. Mobile-first, X-integrated, and centered on verifiable gameplay and $SCORE token mechanics.
