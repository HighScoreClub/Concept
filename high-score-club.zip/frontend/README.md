# Frontend Notes

Mobile wrapper (portrait), UX flows, wallet connect, share templates.