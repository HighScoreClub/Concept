# Mobile Wrapper Notes

iOS TestFlight first, Android APK, portrait gameplay, WebView wrapper.